from django.apps import AppConfig


class CafeappConfig(AppConfig):
    name = 'cafeapp'
