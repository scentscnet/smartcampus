from django.db import models

from django.utils.translation import gettext as _
from taggit.managers import TaggableManager
from taggit.models import Tag, TaggedItemBase

class Blog(models.Model):
    title = models.CharField(max_length=200)


    def __str__(self):
        return self.title

class Comment(models.Model):
    comment = models.TextField()
    date = models.DateTimeField(auto_now_add=True)
    post = models.ForeignKey(Blog, on_delete=models.CASCADE)

    def __str__(self):
        return self.comment

class City(models.Model):
    name = models.CharField(max_length=255)
    state = models.CharField(max_length=255)

    class Meta:
      verbose_name_plural = "cities"

    def __str__(self):
        return self.name

# Create your models here.


    
class Subject(models.Model):
    CATEGORY_CHOICES=[
        ('전공', '전공'),
        ('교양', '교양'),
    ]

    id = models.IntegerField(primary_key=True)
    semester=models.CharField(_("semester"), blank=False,max_length=255)
    series_num=models.CharField(_("series_num"), blank=False,max_length=255)
    num=models.IntegerField(_("num"), blank=False) 
    category=models.CharField(_("category"),  blank=False, choices=CATEGORY_CHOICES, max_length=255) 
    department= models.CharField(_("department"),  blank=False, max_length=255) 
    name=models.CharField(_("name"), blank=False, max_length=255) 
    professor=models.CharField(_("professor"), blank=False, max_length=255) 
    credit=models.CharField(_("credit"), blank=False, max_length=255) 
    words= models.TextField(_("words"), blank=True)
    #keywords=models.TextField(_("keywords"), blank=True)
    # semester=models.DateField(_("semester"), blank=False) 
    # tags=TaggableManager(_("tags"), blank=True)
    
    class Meta:
        # 모델 객체 리스트 출력할 때 어떻게 할 것인가 
        ordering=('id',)

    def __str__(self):
        return self.series_num


class Kmooc(models.Model):
    id = models.IntegerField(primary_key=True)
    name = models.CharField(_("name"),  blank=False, max_length=255)
    midclassify=models.CharField(_("midclassify"), max_length=255)
    level= models.CharField(_("level"), max_length=255)
    image= models.URLField(_("image"))
    link= models.URLField(_("link")) 
    subject = models.ForeignKey(Subject, blank=True, related_name="sub_mooc", null=True, on_delete=models.CASCADE)

    def __str__(self):
        return self.name

#class Sort(keyword):
#    a=len(keyword)
#    def __init__(self) -> None:
#        super().__init__()
#    def __str__(self):
#        return self.a
